package com.bank.socket;

public class Account {
	public Account(int iD) {
		uid = iD;
	}

	public int uid, balance;
}