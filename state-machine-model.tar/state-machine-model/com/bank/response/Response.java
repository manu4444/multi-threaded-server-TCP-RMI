package com.bank.response;

import java.io.Serializable;

public abstract class Response implements Serializable {
	public abstract String toString();

}
